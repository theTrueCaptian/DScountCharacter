Here is how to run:
java -jar "F:\DScountCharacter\dist\DScountCharacter.jar"

******************************************************************************
Note: Please replace F with your directory to where this jar file is copied.
******************************************************************************